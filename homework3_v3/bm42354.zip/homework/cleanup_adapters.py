import os
import shutil

def clean_model_dir(model_dir):
    print(f"Cleaning: {model_dir}")
    for fname in os.listdir(model_dir):
        fpath = os.path.join(model_dir, fname)
        if fname not in {"adapter_model.safetensors", "adapter_config.json"}:
            if os.path.isdir(fpath):
                shutil.rmtree(fpath)
                print(f"Deleted folder: {fpath}")
            else:
                os.remove(fpath)
                print(f"Deleted file: {fpath}")

if __name__ == "__main__":
    for model_dir in ["homework/rft_model", "homework/sft_model"]:
        if os.path.exists(model_dir):
            clean_model_dir(model_dir)
        else:
            print(f"Directory not found: {model_dir}")
